import json
import requests
from flask import Flask, render_template, request, jsonify, redirect, url_for, session
from functools import wraps
from database import get_db, init_db, migrate_db
from config import SECRET_KEY, ADMIN_USERNAME, ADMIN_PASSWORD, MP_ACCESS_TOKEN, MP_BASE_URL

app = Flask(__name__)
app.secret_key = SECRET_KEY

# ---------- Auth ----------
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('admin_logged_in'):
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated


@app.route('/admin/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = request.form.get('username')
        pwd = request.form.get('password')
        if user == ADMIN_USERNAME and pwd == ADMIN_PASSWORD:
            session['admin_logged_in'] = True
            return redirect(url_for('admin_dashboard'))
        return render_template('login.html', error='Usuário ou senha inválidos')
    return render_template('login.html')


@app.route('/admin/logout')
def logout():
    session.pop('admin_logged_in', None)
    return redirect(url_for('login'))


# ---------- Frontend ----------
@app.route('/')
def index():
    return render_template('index.html')


# ---------- API ----------
@app.route('/api/cardapio', methods=['GET'])
def api_cardapio():
    db = get_db()
    cat = request.args.get('categoria')
    if cat:
        rows = db.execute(
            'SELECT p.id, p.nome, p.descricao, p.preco, p.imagem, c.nome as categoria '
            'FROM produtos p JOIN categorias c ON p.categoria_id = c.id '
            'WHERE p.ativo = 1 AND c.nome = ? ORDER BY p.id',
            (cat,)
        ).fetchall()
    else:
        rows = db.execute(
            'SELECT p.id, p.nome, p.descricao, p.preco, p.imagem, c.nome as categoria '
            'FROM produtos p JOIN categorias c ON p.categoria_id = c.id '
            'WHERE p.ativo = 1 ORDER BY p.id'
        ).fetchall()
    db.close()
    return jsonify([dict(r) for r in rows])


@app.route('/api/categorias', methods=['GET'])
def api_categorias():
    db = get_db()
    rows = db.execute('SELECT id, nome FROM categorias ORDER BY id').fetchall()
    db.close()
    return jsonify([dict(r) for r in rows])


# ---------- MERCADO PAGO ----------
def mp_headers():
    return {
        'Authorization': f'Bearer {MP_ACCESS_TOKEN}',
        'Content-Type': 'application/json'
    }


@app.route('/api/criar-pagamento', methods=['POST'])
def criar_pagamento():
    """Cria pedido + pagamento no Mercado Pago. Retorna dados de PIX ou link de checkout."""
    data = request.get_json()
    nome = data.get('cliente_nome', '').strip()
    telefone = data.get('cliente_telefone', '').strip()
    endereco = data.get('cliente_endereco', '').strip()
    itens = data.get('itens', [])
    observacao = data.get('observacao', '').strip()
    metodo = data.get('metodo_pagamento', 'pix').strip()

    if not nome or not itens:
        return jsonify({'error': 'Nome e itens são obrigatórios'}), 400

    total = sum(item.get('preco', 0) * item.get('quantidade', 1) for item in itens)
    itens_json = json.dumps(itens, ensure_ascii=False)

    # Salva pedido no banco
    db = get_db()
    cur = db.execute(
        'INSERT INTO pedidos (cliente_nome, cliente_telefone, cliente_endereco, itens, total, metodo_pagamento, observacao, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        (nome, telefone, endereco, itens_json, total, metodo, observacao, 'aguardando_pagamento' if metodo != 'dinheiro' else 'pendente')
    )
    pedido_id = cur.lastrowid
    db.commit()
    db.close()

    if metodo == 'dinheiro':
        return jsonify({
            'pedido_id': pedido_id,
            'total': total,
            'metodo': 'dinheiro',
            'status': 'pendente',
            'mensagem': 'Pagamento na entrega'
        }), 201

    if metodo == 'pix':
        # Cria pagamento PIX direto via API
        items_list = []
        for item in itens:
            items_list.append({
                'title': item['nome'],
                'unit_price': float(item['preco']),
                'quantity': int(item.get('quantidade', 1)),
                'currency_id': 'BRL'
            })

        preference_data = {
            'items': items_list,
            'payer': {
                'name': nome,
                'email': f'pedido-{pedido_id}@burguervila.com'
            },
            'payment_methods': {
                'default_payment_method_id': 'pix'
            },
            'external_reference': str(pedido_id),
            'notification_url': request.url_root.rstrip('/') + '/api/webhook',
            'back_urls': {
                'success': request.url_root.rstrip('/') + '/?pagamento=sucesso',
                'failure': request.url_root.rstrip('/') + '/?pagamento=falha'
            }
        }

        try:
            resp = requests.post(
                f'{MP_BASE_URL}/checkout/preferences',
                headers=mp_headers(),
                json=preference_data,
                timeout=10
            )
            pref_result = resp.json()

            if resp.status_code == 201 and 'init_point' in pref_result:
                # Agora cria o pagamento PIX para obter o QR code
                pix_payment_data = {
                    'transaction_amount': total,
                    'description': f'Burguer da Vila - Pedido #{pedido_id}',
                    'payment_method_id': 'pix',
                    'external_reference': str(pedido_id),
                    'payer': {
                        'email': f'pedido-{pedido_id}@burguervila.com',
                        'first_name': nome
                    }
                }

                pay_resp = requests.post(
                    f'{MP_BASE_URL}/v1/payments',
                    headers=mp_headers(),
                    json=pix_payment_data,
                    timeout=10
                )
                pay_result = pay_resp.json()

                if pay_resp.status_code == 201 and pay_result.get('status') == 'pending':
                    point_of_interaction = pay_result.get('point_of_interaction', {})
                    qr_data = point_of_interaction.get('transaction_data', {})

                    # Salva MP payment_id no banco
                    db = get_db()
                    db.execute('UPDATE pedidos SET mp_payment_id = ? WHERE id = ?',
                               (pay_result.get('id'), pedido_id))
                    db.commit()
                    db.close()

                    return jsonify({
                        'pedido_id': pedido_id,
                        'total': total,
                        'metodo': 'pix',
                        'status': 'aguardando_pagamento',
                        'qr_code': qr_data.get('qr_code', ''),
                        'qr_code_base64': qr_data.get('qr_code_base64', ''),
                        'ticket_url': qr_data.get('ticket_url', ''),
                        'payment_id': pay_result.get('id'),
                        'checkout_url': pref_result.get('init_point', '')
                    }), 201

            # Fallback: só retorna link de checkout
            return jsonify({
                'pedido_id': pedido_id,
                'total': total,
                'metodo': 'pix',
                'status': 'aguardando_pagamento',
                'checkout_url': pref_result.get('init_point', ''),
                'fallback': True
            }), 201

        except requests.RequestException as e:
            return jsonify({
                'error': 'Erro ao conectar com Mercado Pago',
                'pedido_id': pedido_id,
                'checkout_url': ''
            }), 500

    if metodo == 'cartao':
        # Checkout Pro - redirect to Mercado Pago hosted checkout
        items_list = []
        for item in itens:
            items_list.append({
                'title': item['nome'],
                'unit_price': float(item['preco']),
                'quantity': int(item.get('quantidade', 1)),
                'currency_id': 'BRL'
            })

        preference_data = {
            'items': items_list,
            'payer': {
                'name': nome,
                'email': f'pedido-{pedido_id}@burguervila.com'
            },
            'external_reference': str(pedido_id),
            'notification_url': request.url_root.rstrip('/') + '/api/webhook',
            'back_urls': {
                'success': request.url_root.rstrip('/') + '/?pagamento=sucesso',
                'failure': request.url_root.rstrip('/') + '/?pagamento=falha'
            }
        }

        try:
            resp = requests.post(
                f'{MP_BASE_URL}/checkout/preferences',
                headers=mp_headers(),
                json=preference_data,
                timeout=10
            )
            pref_result = resp.json()

            if resp.status_code == 201 and 'init_point' in pref_result:
                return jsonify({
                    'pedido_id': pedido_id,
                    'total': total,
                    'metodo': 'cartao',
                    'status': 'aguardando_pagamento',
                    'checkout_url': pref_result['init_point']
                }), 201

            return jsonify({'error': 'Erro ao criar preferência'}), 500
        except requests.RequestException:
            return jsonify({'error': 'Erro ao conectar com Mercado Pago'}), 500

    return jsonify({'error': 'Método de pagamento inválido'}), 400


@app.route('/api/webhook', methods=['GET', 'POST'])
def webhook():
    """Recebe notificações do Mercado Pago sobre status de pagamento."""
    # GET - Mercado Pago validates the webhook
    if request.method == 'GET':
        challenge = request.args.get('challenge', '')
        return jsonify({'answer': challenge}) if challenge else ('', 200)

    # POST - payment notification
    data = request.get_json() or {}

    if data.get('type') == 'payment':
        payment_id = data.get('data', {}).get('id')

        if payment_id:
            # Busca detalhes do pagamento
            try:
                resp = requests.get(
                    f'{MP_BASE_URL}/v1/payments/{payment_id}',
                    headers=mp_headers(),
                    timeout=10
                )
                payment = resp.json()
                status = payment.get('status')
                external_ref = payment.get('external_reference')

                if external_ref:
                    db = get_db()
                    if status == 'approved':
                        db.execute("UPDATE pedidos SET status = 'pago' WHERE id = ?", (external_ref,))
                    elif status in ('cancelled', 'rejected', 'refunded'):
                        db.execute("UPDATE pedidos SET status = 'cancelado' WHERE id = ?", (external_ref,))
                    db.commit()
                    db.close()
            except Exception:
                pass

    return ('', 200)


@app.route('/api/pedidos/<int:id>/status', methods=['GET'])
def verificar_status(id):
    """Cliente consulta status do pedido (para polling de pagamento)."""
    db = get_db()
    row = db.execute('SELECT id, status, total, metodo_pagamento FROM pedidos WHERE id = ?', (id,)).fetchone()
    db.close()
    if not row:
        return jsonify({'error': 'Pedido não encontrado'}), 404
    return jsonify(dict(row))


@app.route('/api/pedidos', methods=['POST'])
def api_pedidos_create():
    """Legacy endpoint - still works for simple orders (cash only)."""
    data = request.get_json()
    nome = data.get('cliente_nome', '').strip()
    telefone = data.get('cliente_telefone', '').strip()
    endereco = data.get('cliente_endereco', '').strip()
    itens = data.get('itens', [])
    observacao = data.get('observacao', '').strip()
    metodo = data.get('metodo_pagamento', 'dinheiro').strip()

    if not nome or not itens:
        return jsonify({'error': 'Nome e itens são obrigatórios'}), 400

    total = sum(item.get('preco', 0) * item.get('quantidade', 1) for item in itens)
    itens_json = json.dumps(itens, ensure_ascii=False)

    db = get_db()
    cur = db.execute(
        'INSERT INTO pedidos (cliente_nome, cliente_telefone, cliente_endereco, itens, total, metodo_pagamento, observacao, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        (nome, telefone, endereco, itens_json, total, metodo, observacao, 'pendente' if metodo == 'dinheiro' else 'aguardando_pagamento')
    )
    pedido_id = cur.lastrowid
    db.commit()
    db.close()

    return jsonify({'id': pedido_id, 'total': total, 'status': 'pendente' if metodo == 'dinheiro' else 'aguardando_pagamento', 'metodo': metodo}), 201


@app.route('/api/contato', methods=['POST'])
def api_contato():
    data = request.get_json()
    nome = data.get('nome', '').strip()
    email = data.get('email', '').strip()
    telefone = data.get('telefone', '').strip()
    mensagem = data.get('mensagem', '').strip()

    if not nome or not mensagem:
        return jsonify({'error': 'Nome e mensagem são obrigatórios'}), 400

    db = get_db()
    db.execute('INSERT INTO contatos (nome, email, telefone, mensagem) VALUES (?, ?, ?, ?)',
               (nome, email, telefone, mensagem))
    db.commit()
    db.close()

    return jsonify({'message': 'Mensagem enviada com sucesso'}), 201


# ---------- Admin ----------
@app.route('/admin')
@login_required
def admin_dashboard():
    db = get_db()
    pedidos = db.execute('SELECT * FROM pedidos ORDER BY criado_em DESC').fetchall()
    produtos = db.execute(
        'SELECT p.*, c.nome as categoria_nome FROM produtos p JOIN categorias c ON p.categoria_id = c.id ORDER BY p.id'
    ).fetchall()
    categorias = db.execute('SELECT id, nome FROM categorias ORDER BY id').fetchall()
    contatos = db.execute('SELECT * FROM contatos ORDER BY criado_em DESC').fetchall()
    db.close()
    return render_template('admin.html',
                           pedidos=[dict(p) for p in pedidos],
                           produtos=[dict(p) for p in produtos],
                           categorias=[dict(c) for c in categorias],
                           contatos=[dict(c) for c in contatos])


@app.route('/admin/pedidos/<int:id>/status', methods=['POST'])
@login_required
def update_pedido_status(id):
    data = request.get_json()
    status = data.get('status', 'pendente')
    db = get_db()
    db.execute('UPDATE pedidos SET status = ? WHERE id = ?', (status, id))
    db.commit()
    db.close()
    return jsonify({'message': 'Status atualizado'})


@app.route('/admin/produto', methods=['POST'])
@login_required
def add_produto():
    nome = request.form.get('nome')
    descricao = request.form.get('descricao', '')
    preco = float(request.form.get('preco', 0))
    categoria_id = int(request.form.get('categoria_id', 1))
    if nome and preco:
        db = get_db()
        db.execute('INSERT INTO produtos (nome, descricao, preco, categoria_id) VALUES (?, ?, ?, ?)',
                   (nome, descricao, preco, categoria_id))
        db.commit()
        db.close()
    return redirect(url_for('admin_dashboard'))


@app.route('/admin/produto/<int:id>/toggle', methods=['POST'])
@login_required
def toggle_produto(id):
    db = get_db()
    db.execute('UPDATE produtos SET ativo = NOT ativo WHERE id = ?', (id,))
    db.commit()
    db.close()
    return redirect(url_for('admin_dashboard'))


@app.route('/admin/produto/<int:id>/delete', methods=['POST'])
@login_required
def delete_produto(id):
    db = get_db()
    db.execute('DELETE FROM produtos WHERE id = ?', (id,))
    db.commit()
    db.close()
    return redirect(url_for('admin_dashboard'))


# ---------- Init ----------
init_db()
migrate_db()

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
