import sqlite3
from config import DATABASE


def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    c = conn.cursor()

    c.execute('''CREATE TABLE IF NOT EXISTS categorias (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL UNIQUE
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS produtos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        descricao TEXT,
        preco REAL NOT NULL,
        categoria_id INTEGER NOT NULL,
        ativo INTEGER DEFAULT 1,
        imagem TEXT,
        FOREIGN KEY (categoria_id) REFERENCES categorias(id)
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS pedidos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        cliente_nome TEXT NOT NULL,
        cliente_telefone TEXT,
        cliente_endereco TEXT,
        itens TEXT NOT NULL,
        total REAL NOT NULL,
        metodo_pagamento TEXT,
        observacao TEXT,
        status TEXT DEFAULT 'pendente',
        criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS contatos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        email TEXT,
        telefone TEXT,
        mensagem TEXT NOT NULL,
        criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')

    # Seed initial data
    c.execute("SELECT COUNT(*) FROM categorias")
    if c.fetchone()[0] == 0:
        for cat in ['Hamburgueres', 'Novidades', 'Pasteis']:
            c.execute("INSERT INTO categorias (nome) VALUES (?)", (cat,))

        conn.commit()
        cat_id = {}
        c.execute("SELECT id, nome FROM categorias")
        for row in c.fetchall():
            cat_id[row['nome']] = row['id']

        hamburgueres = [
            ('X-Tudo', 'Hambúrguer artesanal, mussarela, alface, tomate, bacon, ovo, calabresa e presunto.', 20.00),
            ('X-Bacon', 'Alface, tomate, hambúrguer artesanal, bacon crocante e mussarela.', 17.00),
            ('X-Egg', 'Hambúrguer artesanal, ovo mal passado, bacon crocante e mussarela.', 17.00),
            ('X-Salada', 'Alface, tomate, hambúrguer artesanal e maionese especial.', 15.00),
            ('X-Burguer', 'Hambúrguer artesanal, mussarela e maionese especial.', 12.00),
        ]
        novidades = [
            ('Duplo Cheddar Bacon', '2 hambúrgueres, bacon, mussarela, queijo prato, cheddar e maionese caseira.', 25.00),
            ('Catupiry Especial', 'Catupiry empanado, hambúrguer caseiro, maionese caseira, mussarela e queijo prato.', 25.00),
            ('Misto Quente', 'Presunto e mussarela.', 7.00),
        ]
        pasteis = [
            ('Frango com Catupiry', None, 8.00),
            ('Pizza', None, 8.00),
            ('Carne', None, 8.00),
            ('Carne com Queijo', None, 8.00),
            ('Calabresa com Queijo', None, 8.00),
            ('Mussarela', None, 8.00),
            ('Bacon com Queijo', None, 8.00),
        ]

        for nome, desc, preco in hamburgueres:
            c.execute("INSERT INTO produtos (nome, descricao, preco, categoria_id) VALUES (?, ?, ?, ?)",
                      (nome, desc, preco, cat_id['Hamburgueres']))
        for nome, desc, preco in novidades:
            c.execute("INSERT INTO produtos (nome, descricao, preco, categoria_id) VALUES (?, ?, ?, ?)",
                      (nome, desc, preco, cat_id['Novidades']))
        for nome, desc, preco in pasteis:
            c.execute("INSERT INTO produtos (nome, descricao, preco, categoria_id) VALUES (?, ?, ?, ?)",
                      (nome, desc, preco, cat_id['Pasteis']))

    conn.commit()
    conn.close()


def migrate_db():
    """Add missing columns if they don't exist."""
    conn = get_db()
    c = conn.cursor()
    c.execute("PRAGMA table_info(pedidos)")
    cols = [row[1] for row in c.fetchall()]
    if 'cliente_endereco' not in cols:
        c.execute("ALTER TABLE pedidos ADD COLUMN cliente_endereco TEXT")
    if 'metodo_pagamento' not in cols:
        c.execute("ALTER TABLE pedidos ADD COLUMN metodo_pagamento TEXT")
    if 'mp_payment_id' not in cols:
        c.execute("ALTER TABLE pedidos ADD COLUMN mp_payment_id INTEGER")
    conn.commit()
    conn.close()


if __name__ == '__main__':
    init_db()
    migrate_db()
    print('Database initialized.')
