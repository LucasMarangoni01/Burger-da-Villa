import os

BASE_DIR = os.path.dirname(__file__)

DATABASE = os.path.join(BASE_DIR, 'burguer_vila.db')
SECRET_KEY = os.environ.get('SECRET_KEY', 'burguer-da-vila-secret-key')

# Admin credentials
ADMIN_USERNAME = 'admin'
ADMIN_PASSWORD = 'burguer123'

# Mercado Pago - get your access token at: https://www.mercadopago.com.br/developers/panel/app
MP_ACCESS_TOKEN = os.environ.get('MP_ACCESS_TOKEN', 'TEST-123456789-replace-with-your-token')
MP_PUBLIC_KEY = os.environ.get('MP_PUBLIC_KEY', 'TEST-replace-with-your-public-key')
MP_BASE_URL = 'https://api.mercadopago.com'
